# pi-mairinque-002
Site desenvolvido com Python e com o Framework Flask através do curso feito pela Univesp para base do Projeto Integrador
Aplicação disponivel em https://pi-mairinque-002.herokuapp.com


Para instalar:
````console
py -3 -m venv .venv - Instala o ambiente virtual
pip install -r requirements-dev.txt - instala todas as dependências

````

![GitHub Workflow Status](https://img.shields.io/github/workflow/status/FlavioFMBorges/pi-mairinque-002/CIPI?style=plastic)
[![Updates](https://pyup.io/repos/github/FlavioFMBorges/pi-mairinque-002/shield.svg)](https://pyup.io/repos/github/FlavioFMBorges/pi-mairinque-002/)
[![Python 3](https://pyup.io/repos/github/FlavioFMBorges/pi-mairinque-002/python-3-shield.svg)](https://pyup.io/repos/github/FlavioFMBorges/pi-mairinque-002/)
