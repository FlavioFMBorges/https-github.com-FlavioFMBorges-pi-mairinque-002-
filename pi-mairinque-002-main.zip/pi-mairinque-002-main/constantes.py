paleta_cores = ['#2c559c', '#2b62cf', '#70a0ff', '#1a3770']
rotulos = ['18 a 27 anos', '28 a 39 anos', '40 a 55 anos', 'acima de 55 anos']